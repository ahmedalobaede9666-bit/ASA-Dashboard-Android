(() => {
  'use strict';

  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => Array.from(root.querySelectorAll(s));
  const fmt = new Intl.NumberFormat('ar-IQ', {maximumFractionDigits:1});
  let model = null;
  let deferredInstall = null;
  let toastTimer = null;

  const els = {
    welcome: $('#welcome'), dashboardPage: $('#dashboardPage'), subjectsPage: $('#subjectsPage'), studentsPage: $('#studentsPage'), settingsPage: $('#settingsPage'),
    bottomNav: $('#bottomNav'), fileInput: $('#fileInput'), loading: $('#loading'), loadingText: $('#loadingText'), toast: $('#toast'),
    modal: $('#modal'), modalTitle: $('#modalTitle'), modalBody: $('#modalBody')
  };

  function esc(v=''){ return String(v).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }
  function num(v, fallback='—'){ return Number.isFinite(v) ? fmt.format(v) : fallback; }
  function pct(v){ return Number.isFinite(v) ? `${fmt.format(v)}٪` : '—'; }
  function statusLabel(s){ return s==='pass'?'ناجح':s==='fail'?'راسب':'بدون نتيجة'; }
  function statusClass(s){ return s==='pass'?'pass':s==='fail'?'fail':'pending'; }
  function grade(v){ return Number.isFinite(v)?num(v):'—'; }
  function safeName(s){ return (s?.displayName || s?.name || '—').replace(/[⭐*]/g,'').trim(); }

  function showToast(message, type=''){
    els.toast.textContent = message;
    els.toast.className = `toast ${type}`.trim();
    clearTimeout(toastTimer); toastTimer=setTimeout(()=>els.toast.classList.add('hidden'),3200);
  }
  function setLoading(on,text='قراءة ملف Excel'){
    els.loading.classList.toggle('hidden',!on); els.loadingText.textContent=text;
  }

  function openPicker(){ els.fileInput.value=''; els.fileInput.click(); }

  async function importFile(file){
    if(!file) return;
    const name=file.name||'';
    if(!/\.(xlsx|xlsm)$/i.test(name)){ showToast('اختر ملف Excel بصيغة XLSX أو XLSM.','error'); return; }
    try{
      setLoading(true,'فتح الملف من جهازك');
      const ab=await file.arrayBuffer();
      els.loadingText.textContent='التعرف على قالب الماسترشيت';
      const parsed=await ASAExcelParser.parseArrayBuffer(ab,name);
      els.loadingText.textContent='بناء الإحصائيات والتقارير';
      model=parsed;
      await DB.set('lastModel',model);
      renderAll();
      navigate('dashboard');
      showToast(`تم تحليل ${model.students.length} طالب و${model.subjects.length} مادة بنجاح.`);
    }catch(err){
      console.error(err);
      showToast(err?.message||'تعذر تحليل ملف Excel.','error');
    }finally{ setLoading(false); }
  }

  function renderAll(){
    if(!model){
      els.welcome.classList.remove('hidden');
      [els.dashboardPage,els.subjectsPage,els.studentsPage,els.settingsPage,els.bottomNav].forEach(x=>x.classList.add('hidden'));
      $('#headerSub').textContent='تحليل الماسترشيت';
      renderSettings();
      return;
    }
    els.welcome.classList.add('hidden'); els.bottomNav.classList.remove('hidden');
    $('#headerSub').textContent=model.sourceFile||'الماسترشيت الحالي';
    renderDashboard(); renderSubjects(); renderStudents(); renderSettings();
  }

  function renderDashboard(){
    const s=model.stats;
    $('#collegeName').textContent=model.college||'الكلية';
    const meta=[model.department,model.studyType,model.stage,model.semester,model.academicYear].filter(Boolean);
    $('#metaLine').textContent=meta.join(' • ')||'—';
    const stats=[
      ['عدد الطلاب',s.students,'طالب',''],['عدد المواد',s.subjects,'مادة',''],['نسبة النجاح',pct(s.passRate),`${s.passed} ناجح`,'good'],['متوسط المرحلة',num(s.classAverage),'من 100','gold'],
      ['الناجحون',s.passed,'طالب','good'],['الراسبون',s.failed,'طالب','bad'],['طلاب القرار',s.decisionStudents,'طالب','gold'],['الدور الثاني',s.secondRoundStudents,'طالب','']
    ];
    $('#statsGrid').innerHTML=stats.map(x=>`<div class="card stat ${x[3]}"><span>${esc(x[0])}</span><b>${esc(x[1])}</b><small>${esc(x[2])}</small></div>`).join('');

    const preview=model.subjectStats.slice().sort((a,b)=>b.passRate-a.passRate).slice(0,6);
    $('#subjectPreview').innerHTML=preview.map(st=>{
      const cls=st.passRate>=70?'good':st.passRate>=50?'warn':'bad';
      return `<div class="subject-line" data-subject="${model.subjectStats.indexOf(st)}"><span class="name">${st.subject.ministerial?'⭐ ':''}${esc(safeName(st.subject))}</span><div class="bar"><div class="fill ${cls}" style="width:${Math.max(0,Math.min(100,st.passRate))}%"></div></div><b>${pct(st.passRate)}</b></div>`;
    }).join('') || '<p class="muted">لا توجد بيانات مواد.</p>';

    const strong=s.strongestSubject, weak=s.weakestSubject;
    const smart=[
      ['أعلى معدل',s.topStudent?`${num(s.topStudent.averageNumber)} — ${s.topStudent.name}`:'—'],
      ['أدنى معدل',s.lowestStudent?`${num(s.lowestStudent.averageNumber)} — ${s.lowestStudent.name}`:'—'],
      ['أفضل مادة',strong?`${safeName(strong.subject)} • ${pct(strong.passRate)}`:'—'],
      ['أضعف مادة',weak?`${safeName(weak.subject)} • ${pct(weak.passRate)}`:'—'],
      ['مواد وزارية',String(s.ministerialSubjects)],['بدون نتيجة',String(s.pending)]
    ];
    $('#smartGrid').innerHTML=smart.map(x=>`<div class="smart"><span>${esc(x[0])}</span><b>${esc(x[1])}</b></div>`).join('');

    const top=model.rankedStudents.slice(0,5);
    $('#topStudents').innerHTML=top.length?`<table class="student-table"><thead><tr><th>#</th><th>اسم الطالب</th><th>المعدل</th><th>النتيجة</th></tr></thead><tbody>${top.map((st,i)=>`<tr data-student="${model.students.indexOf(st)}"><td>${i+1}</td><td>${esc(st.name)}</td><td>${num(st.averageNumber)}</td><td><span class="status ${statusClass(st.status)}">${statusLabel(st.status)}</span></td></tr>`).join('')}</tbody></table>`:'<p class="muted">لا توجد معدلات قابلة للترتيب.</p>';
  }

  function renderSubjects(){
    if(!model) return;
    $('#subjectsList').innerHTML=model.subjectStats.map((st,i)=>{
      const cls=st.passRate>=70?'good':st.passRate>=50?'warn':'bad';
      return `<article class="card subject-card" data-subject="${i}"><h3>${st.subject.ministerial?'⭐ ':''}${esc(safeName(st.subject))}</h3><div class="meta">${st.subject.unit?`الوحدة ${esc(st.subject.unit)} • `:''}${st.subject.ministerial?'مادة تقويمية/وزارية':'مادة داخلية'}</div><div class="big-rate">${pct(st.passRate)}</div><div class="bar"><div class="fill ${cls}" style="width:${Math.max(0,Math.min(100,st.passRate))}%"></div></div><div class="metrics-row" style="margin-top:10px"><div class="mini"><span>المتوسط</span><b>${num(st.average)}</b></div><div class="mini"><span>ناجح</span><b>${st.passed}</b></div><div class="mini"><span>راسب</span><b>${st.failed}</b></div><div class="mini"><span>قرار</span><b>${st.decisions}</b></div></div></article>`;
    }).join('');
  }

  function renderStudents(){
    if(!model) return;
    const q=($('#studentSearch')?.value||'').trim(); const f=$('#statusFilter')?.value||'';
    const list=model.students.filter(s=>(!q||s.name.includes(q))&&(!f||s.status===f));
    $('#studentsList').innerHTML=list.map(s=>`<article class="card student-card" data-student="${model.students.indexOf(s)}"><div><div class="name">${esc(s.name)}</div><div class="sub">التسلسل ${s.serial} • <span class="status ${statusClass(s.status)}">${statusLabel(s.status)}</span>${s.hasDecision?' • قرار':''}${s.hasSecondRound?' • دور ثانٍ':''}</div></div><div class="avg">${Number.isFinite(s.averageNumber)?num(s.averageNumber):'—'}</div></article>`).join('') || '<div class="card panel"><p class="muted">لا توجد نتائج مطابقة للبحث.</p></div>';
  }

  function renderSettings(){
    updateConnection();
    const box=$('#fileInfo'); if(!box) return;
    if(!model){ box.innerHTML='<div><span>الملف</span><b>لا يوجد ملف محفوظ</b></div>'; return; }
    box.innerHTML=`<div><span>اسم الملف</span><b>${esc(model.sourceFile||'—')}</b></div><div><span>ورقة العمل</span><b>${esc(model.sheetName||'الأولى')}</b></div><div><span>الطلاب</span><b>${model.students.length}</b></div><div><span>المواد</span><b>${model.subjects.length}</b></div><div><span>آخر تحليل</span><b>${new Date(model.importedAt).toLocaleString('ar-IQ')}</b></div>`;
  }

  function showStudent(index){
    const s=model?.students?.[index]; if(!s) return;
    els.modalTitle.textContent=s.name;
    let info='';
    if(s.failedSubjects) info+=`<div class="note-box"><b>مواد الرسوب:</b> ${esc(s.failedSubjects)}</div>`;
    if(s.carry) info+=`<div class="note-box"><b>التحميل:</b> ${esc(s.carry)}</div>`;
    if(s.notes) info+=`<div class="note-box"><b>الملاحظات:</b> ${esc(s.notes)}</div>`;
    const cards=s.grades.map(g=>{
      const total=g.effectiveTotal, cls=Number.isFinite(total)?(total>=50?'pass':'fail'):'';
      return `<div class="grade-card"><div class="grade-head"><h4>${g.ministerial?'⭐ ':''}${esc(g.subjectName)}</h4><span class="grade-total ${cls}">${grade(total)}</span></div><div class="grade-grid"><div><span>السعي</span><b>${grade(g.coursework)}</b></div><div><span>النهائي د1</span><b>${grade(g.firstExam)}</b></div><div><span>مجموع د1</span><b>${grade(g.firstTotal)}</b></div><div><span>النهائي د2</span><b>${grade(g.secondExam)}</b></div><div><span>مجموع د2</span><b>${grade(g.secondTotal)}</b></div><div><span>القرار</span><b>${grade(g.decision)}</b></div></div></div>`;
    }).join('');
    els.modalBody.innerHTML=`<div class="detail-stats"><div class="detail-stat"><span>النتيجة</span><b><span class="status ${statusClass(s.status)}">${esc(s.result||statusLabel(s.status))}</span></b></div><div class="detail-stat"><span>المعدل</span><b>${Number.isFinite(s.averageNumber)?num(s.averageNumber):'—'}</b></div><div class="detail-stat"><span>المجموع</span><b>${Number.isFinite(s.totalNumber)?num(s.totalNumber):esc(s.total||'—')}</b></div><div class="detail-stat"><span>التسلسل</span><b>${s.serial}</b></div><div class="detail-stat"><span>قرار</span><b>${s.hasDecision?'نعم':'لا'}</b></div><div class="detail-stat"><span>دور ثانٍ</span><b>${s.hasSecondRound?'نعم':'لا'}</b></div></div>${info}<h3 style="font-size:14px;margin:16px 0 9px">تفاصيل الدرجات</h3>${cards}`;
    openModal();
  }

  function showSubject(index){
    const st=model?.subjectStats?.[index]; if(!st) return;
    els.modalTitle.textContent=`${st.subject.ministerial?'⭐ ':''}${safeName(st.subject)}`;
    const rows=model.students.map(s=>{
      const g=s.grades[index]; const t=g?.effectiveTotal;
      return {s,t,g};
    }).filter(x=>Number.isFinite(x.t)).sort((a,b)=>b.t-a.t);
    els.modalBody.innerHTML=`<div class="detail-stats"><div class="detail-stat"><span>نسبة النجاح</span><b>${pct(st.passRate)}</b></div><div class="detail-stat"><span>المتوسط</span><b>${num(st.average)}</b></div><div class="detail-stat"><span>المشمولون</span><b>${st.graded}</b></div><div class="detail-stat"><span>ناجح</span><b>${st.passed}</b></div><div class="detail-stat"><span>راسب</span><b>${st.failed}</b></div><div class="detail-stat"><span>قرار</span><b>${st.decisions}</b></div></div><table class="student-table"><thead><tr><th>اسم الطالب</th><th>المجموع</th><th>الحالة</th></tr></thead><tbody>${rows.map(x=>`<tr data-student="${model.students.indexOf(x.s)}"><td>${esc(x.s.name)}</td><td>${num(x.t)}</td><td><span class="status ${x.t>=50?'pass':'fail'}">${x.t>=50?'ناجح':'راسب'}</span></td></tr>`).join('')}</tbody></table>`;
    openModal();
  }

  function openModal(){ els.modal.classList.remove('hidden'); document.body.style.overflow='hidden'; }
  function closeModal(){ els.modal.classList.add('hidden'); document.body.style.overflow=''; }

  function navigate(page){
    if(!model && page!=='settings'){ renderAll(); return; }
    const map={dashboard:els.dashboardPage,subjects:els.subjectsPage,students:els.studentsPage,settings:els.settingsPage};
    Object.values(map).forEach(x=>x.classList.add('hidden')); map[page]?.classList.remove('hidden');
    $$('[data-nav]',els.bottomNav).forEach(b=>b.classList.toggle('active',b.dataset.nav===page));
    if(page==='students') renderStudents(); if(page==='settings') renderSettings();
    window.scrollTo({top:0,behavior:'smooth'});
  }

  function showInstallHelp(){
    const isIOS=/iphone|ipad|ipod/i.test(navigator.userAgent);
    els.modalTitle.textContent='تثبيت ASA Dashboard';
    els.modalBody.innerHTML=isIOS
      ? `<div class="card panel" style="box-shadow:none"><p class="muted" style="margin-top:0">على iPhone:</p><ol class="muted" style="padding-right:20px"><li>افتح هذا الرابط في <b>Safari</b>.</li><li>اضغط زر <b>المشاركة</b>.</li><li>اختر <b>إضافة إلى الشاشة الرئيسية</b>.</li><li>اضغط <b>إضافة</b>.</li></ol><p class="muted">بعدها سيظهر ASA Dashboard كأيقونة تطبيق على الشاشة الرئيسية.</p></div>`
      : `<div class="card panel" style="box-shadow:none"><p class="muted">من قائمة المتصفح اختر <b>تثبيت التطبيق</b> أو <b>Add to Home screen</b>. إذا ظهر زر التثبيت في هذه الصفحة يمكنك استخدامه مباشرة.</p></div>`;
    openModal();
  }

  async function requestInstall(){
    if(deferredInstall){ deferredInstall.prompt(); await deferredInstall.userChoice; deferredInstall=null; return; }
    showInstallHelp();
  }

  function updateConnection(){
    const c=$('#connectionStatus'); if(c) c.textContent=navigator.onLine?'متصل':'دون إنترنت';
  }

  const DB={
    name:'asa-dashboard-pwa',store:'state',
    open(){ return new Promise((res,rej)=>{ const q=indexedDB.open(this.name,1); q.onupgradeneeded=()=>{ if(!q.result.objectStoreNames.contains(this.store)) q.result.createObjectStore(this.store); }; q.onsuccess=()=>res(q.result); q.onerror=()=>rej(q.error); }); },
    async get(k){ try{ const db=await this.open(); return await new Promise((res,rej)=>{const tx=db.transaction(this.store,'readonly'),q=tx.objectStore(this.store).get(k);q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error);}); }catch(e){return null;} },
    async set(k,v){ try{ const db=await this.open(); await new Promise((res,rej)=>{const tx=db.transaction(this.store,'readwrite');tx.objectStore(this.store).put(v,k);tx.oncomplete=()=>res();tx.onerror=()=>rej(tx.error);}); }catch(e){console.warn(e);} },
    async clear(){ try{ const db=await this.open(); await new Promise((res,rej)=>{const tx=db.transaction(this.store,'readwrite');tx.objectStore(this.store).clear();tx.oncomplete=()=>res();tx.onerror=()=>rej(tx.error);}); }catch(e){} }
  };

  async function clearLocal(){
    if(!confirm('هل تريد مسح بيانات الماسترشيت المحفوظة من هذا الجهاز؟')) return;
    await DB.clear(); model=null; renderAll(); showToast('تم مسح البيانات المحلية.');
  }

  async function registerSW(){
    if(!('serviceWorker' in navigator)){ $('#offlineStatus').textContent='غير مدعوم'; return; }
    try{ await navigator.serviceWorker.register('./service-worker.js'); $('#offlineStatus').textContent='مفعّل'; }
    catch(e){ console.warn(e); $('#offlineStatus').textContent='يحتاج HTTPS'; }
  }

  function bind(){
    $('#pickWelcome').addEventListener('click',openPicker); $('#importTop').addEventListener('click',openPicker); $('#changeFile').addEventListener('click',openPicker);
    els.fileInput.addEventListener('change',e=>importFile(e.target.files?.[0]));
    els.bottomNav.addEventListener('click',e=>{const b=e.target.closest('[data-nav]');if(b)navigate(b.dataset.nav);});
    document.addEventListener('click',e=>{
      const nav=e.target.closest('[data-nav]'); if(nav&&!nav.closest('#bottomNav')) navigate(nav.dataset.nav);
      const st=e.target.closest('[data-student]'); if(st) showStudent(Number(st.dataset.student));
      const sub=e.target.closest('[data-subject]'); if(sub) showSubject(Number(sub.dataset.subject));
      if(e.target.closest('[data-close-modal]')) closeModal();
    });
    $('#studentSearch').addEventListener('input',renderStudents); $('#statusFilter').addEventListener('change',renderStudents);
    $('#installBtn').addEventListener('click',requestInstall); $('#clearData').addEventListener('click',clearLocal);
    window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstall=e;});
    window.addEventListener('online',updateConnection); window.addEventListener('offline',updateConnection);
    window.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal();});
  }

  async function init(){
    bind(); renderAll(); registerSW();
    const saved=await DB.get('lastModel');
    if(saved?.students?.length && saved?.subjects?.length){ model=saved; renderAll(); navigate('dashboard'); }
  }

  init();
})();
