package com.asa.dashboard;
import java.util.*;

public class StudentData {
    public int serial;
    public String name="";

    // Source values are retained only for audit/display; they do not decide success/failure.
    public String sourceResultFirst="";
    public String sourceResultSecond="";
    public String result="";

    public String failedSubjects="";
    public String carry="";
    public String average="";
    public String total="";
    public String notes="";
    public final List<GradeData> grades = new ArrayList<>();

    public String computedResult(){
        if(grades.isEmpty()) return "بدون نتيجة";
        boolean anyFinalFail=false, anyCompleter=false, anyDecision=false;
        int activeSubjects=0;
        for(GradeData g:grades){
            GradeData.Status st=g.status();
            // Completely blank subject blocks are not counted as a required attempt for this student.
            if(st==GradeData.Status.INCOMPLETE) continue;
            activeSubjects++;
            if(st==GradeData.Status.FAIL) anyFinalFail=true;
            else if(st==GradeData.Status.COMPLETER) anyCompleter=true;
            else if(st==GradeData.Status.PASS_DECISION) anyDecision=true;
        }
        if(activeSubjects==0) return "بيانات ناقصة";
        if(!anyFinalFail && !anyCompleter) return anyDecision?"ناجح بقرار":"ناجح";
        if(anyFinalFail) return "راسب";
        return "مكمل";
    }

    public boolean isPass(){ String x=computedResult(); return x.startsWith("ناجح"); }
    public boolean isFail(){ return "راسب".equals(computedResult()); }
    public boolean isCompleter(){ return "مكمل".equals(computedResult()); }
    public boolean isIncomplete(){ return "بيانات ناقصة".equals(computedResult()) || "بدون نتيجة".equals(computedResult()); }
    public boolean passedByDecision(){ return "ناجح بقرار".equals(computedResult()); }
    public boolean hasDecision(){ for(GradeData g:grades)if(g.decisionWasNeeded())return true; return false; }
    public boolean hasSecondRound(){ for(GradeData g:grades)if(g.hasSecondRoundData())return true; return false; }

    public String latestSourceResult(){
        if(sourceResultSecond!=null && !sourceResultSecond.trim().isEmpty()) return sourceResultSecond.trim();
        if(sourceResultFirst!=null && !sourceResultFirst.trim().isEmpty()) return sourceResultFirst.trim();
        return "";
    }

    public Double averageNumber(){ return number(average); }
    public Double totalNumber(){ return number(total); }
    private Double number(String x){ if(x==null)return null; String c=x.replaceAll("[^0-9.\\-]",""); if(c.isEmpty())return null; try{return Double.parseDouble(c);}catch(Exception e){return null;} }
}
