package com.asa.dashboard;

public class GradeData {
    public enum Status { PASS, PASS_DECISION, COMPLETER, FAIL, INCOMPLETE }

    public String subjectName="";
    public Double coursework;
    public Double firstExam;
    public Double firstTotal;
    public Double secondExam;
    public Double secondTotal;
    public Double decision;
    public boolean ministerial;

    public boolean hasFirstRoundData(){ return firstExam!=null || firstTotal!=null || coursework!=null; }
    public boolean hasSecondRoundData(){ return secondExam!=null || secondTotal!=null; }

    public Double firstBaseTotal(){
        if(firstTotal!=null) return firstTotal;
        if(coursework!=null && firstExam!=null) return coursework + firstExam;
        return null;
    }

    public Double secondBaseTotal(){
        if(secondTotal!=null) return secondTotal;
        if(coursework!=null && secondExam!=null) return coursework + secondExam;
        return null;
    }

    /** The latest available attempt is authoritative: second round first, otherwise first round. */
    public Double baseTotal(){ return hasSecondRoundData() ? secondBaseTotal() : firstBaseTotal(); }

    /** Decision is applied to the final total, not to the exam mark itself. */
    public Double effectiveTotal(){
        Double base=baseTotal();
        if(base==null) return null;
        return base + (decision==null?0:decision);
    }

    public Double activeExam(){ return hasSecondRoundData() ? secondExam : firstExam; }

    /**
     * A subject is passed when the final total is >= 50.
     * Ministerial/evaluative subjects (⭐) also require the active final exam mark >= 30.
     */
    public boolean passesCurrentAttempt(){
        Double total=effectiveTotal();
        if(total==null || total<50) return false;
        if(ministerial){
            Double exam=activeExam();
            return exam!=null && exam>=30;
        }
        return true;
    }

    public boolean decisionWasNeeded(){
        if(!passesCurrentAttempt()) return false;
        Double base=baseTotal();
        return decision!=null && decision>0 && base!=null && base<50 && effectiveTotal()!=null && effectiveTotal()>=50;
    }

    public Status status(){
        if(!hasFirstRoundData() && !hasSecondRoundData()) return Status.INCOMPLETE;
        if(passesCurrentAttempt()) return decisionWasNeeded()?Status.PASS_DECISION:Status.PASS;
        if(hasSecondRoundData()) return Status.FAIL;
        return Status.COMPLETER;
    }

    public String statusLabel(){
        switch(status()){
            case PASS_DECISION: return "ناجح بقرار";
            case PASS: return "ناجح";
            case COMPLETER: return "مكمل";
            case FAIL: return "راسب";
            default: return "بيانات ناقصة";
        }
    }
}
