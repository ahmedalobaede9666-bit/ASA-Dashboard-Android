package com.asa.dashboard;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.text.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final int PICK_XLSX=1001;
    private final int BG=Color.rgb(7,16,29), PANEL=Color.rgb(14,26,44), PANEL2=Color.rgb(18,35,58), PANEL3=Color.rgb(22,46,73), TEXT=Color.rgb(238,247,255), MUTED=Color.rgb(143,168,191), CYAN=Color.rgb(50,216,255), GOLD=Color.rgb(242,198,109), GREEN=Color.rgb(77,224,163), RED=Color.rgb(255,127,145);
    private LinearLayout root, content;
    private MasterSheetData data;

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG); buildShell(); showWelcome(); }
    private TextView tv(String t,int sp,boolean bold){ TextView v=new TextView(this); v.setText(t); v.setTextColor(TEXT); v.setTextSize(sp); v.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); v.setTextDirection(View.TEXT_DIRECTION_RTL); v.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); v.setPadding(dp(12),dp(8),dp(12),dp(8)); return v; }
    private void buildShell(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); root.setBackgroundColor(BG); setContentView(root);
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); top.setPadding(dp(14),dp(10),dp(14),dp(10)); top.setBackgroundColor(PANEL);
        ImageView icon=new ImageView(this); icon.setImageResource(R.drawable.asa_icon); icon.setScaleType(ImageView.ScaleType.CENTER_CROP); top.addView(icon,new LinearLayout.LayoutParams(dp(58),dp(58)));
        LinearLayout titles=new LinearLayout(this); titles.setOrientation(LinearLayout.VERTICAL); titles.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); TextView t=tv("ASA Dashboard",20,true), s=tv("تحليل الماسترشيت — نسخة الهاتف",11,false); s.setTextColor(MUTED); titles.addView(t); titles.addView(s); top.addView(titles,new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1)); root.addView(top);
        ScrollView sc=new ScrollView(this); sc.setFillViewport(true); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); content.setPadding(dp(12),dp(12),dp(12),dp(30)); sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
    }
    private Button button(String t){ Button b=new Button(this); b.setText(t); b.setTextDirection(View.TEXT_DIRECTION_RTL); b.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); b.setTextColor(TEXT); b.setBackgroundTintList(ColorStateList.valueOf(PANEL2)); b.setAllCaps(false); b.setTextSize(14); return b; }
    private void showWelcome(){ content.removeAllViews(); TextView h=tv("مرحباً بك في ASA Dashboard",24,true); content.addView(h); TextView p=tv("استورد ملف الماسترشيت XLSX من هاتفك، وسيحوّله التطبيق إلى لوحة إحصائية عربية مع تفاصيل الطلاب والمواد.",14,false); p.setTextColor(MUTED); content.addView(p); Button importBtn=button("استيراد ملف الماسترشيت"); importBtn.setOnClickListener(v->pickFile()); content.addView(importBtn,new LinearLayout.LayoutParams(-1,dp(58))); }
    private void pickFile(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"); startActivityForResult(i,PICK_XLSX); }
    @Override protected void onActivityResult(int r,int code,Intent i){ super.onActivityResult(r,code,i); if(r==PICK_XLSX&&code==RESULT_OK&&i!=null){ Uri u=i.getData(); if(u!=null) loadFile(u); } }
    private void loadFile(Uri u){ content.removeAllViews(); content.addView(tv("جارٍ تحليل الماسترشيت...",18,true)); new Thread(()->{ try{ MasterSheetData d=new ExcelMasterSheetReader().read(this,u); runOnUiThread(()->{data=d; showDashboard();}); }catch(Exception e){runOnUiThread(()->showError(e));}}).start(); }
    private void showError(Exception e){ content.removeAllViews(); TextView x=tv("تعذر قراءة الملف",22,true); x.setTextColor(RED); content.addView(x); TextView d=tv(e.getMessage()==null?e.toString():e.getMessage(),13,false); d.setTextColor(MUTED); content.addView(d); Button b=button("اختيار ملف آخر"); b.setOnClickListener(v->pickFile()); content.addView(b); }

    private void showDashboard(){
        content.removeAllViews();
        LinearLayout hero=panel(); hero.setOrientation(LinearLayout.VERTICAL); hero.addView(tv(blank(data.college,"الكلية"),22,true)); TextView meta=tv(joinMeta(),12,false); meta.setTextColor(MUTED); hero.addView(meta); content.addView(hero);
        LinearLayout actions=new LinearLayout(this); actions.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); actions.setPadding(0,dp(8),0,dp(4)); Button students=button("الطلاب"), subjects=button("تحليل المواد"), another=button("ملف آخر"); students.setOnClickListener(v->showStudents()); subjects.setOnClickListener(v->showSubjects()); another.setOnClickListener(v->pickFile()); actions.addView(students,new LinearLayout.LayoutParams(0,dp(50),1)); actions.addView(subjects,new LinearLayout.LayoutParams(0,dp(50),1)); actions.addView(another,new LinearLayout.LayoutParams(0,dp(50),1)); content.addView(actions);

        content.addView(sectionTitle("الملخص التنفيذي"));
        addStatPair("الطلاب",String.valueOf(data.students.size()),"المواد",String.valueOf(data.subjects.size()));
        addStatPair("نسبة النجاح",pct(data.passRate()),"متوسط المرحلة",num(data.averageOfAverages()));
        addStatPair("الناجحون",String.valueOf(data.passedCount()),"الراسبون",String.valueOf(data.failedCount()));
        addStatPair("المكملون",String.valueOf(data.completerCount()),"طلاب القرار",String.valueOf(data.decisionStudentsCount()));
        addStatPair("الدور الثاني",String.valueOf(data.secondRoundStudentsCount()),"مواد وزارية ⭐",String.valueOf(data.ministerialCount()));
        if(data.incompleteCount()>0) addStatPair("بيانات ناقصة",String.valueOf(data.incompleteCount()),"الحالة", "تحتاج مراجعة");

        StudentData top=data.topStudent(), low=data.lowestStudent(); SubjectStats weak=data.weakestSubject(), strong=data.strongestSubject();
        content.addView(sectionTitle("مؤشرات ذكية"));
        LinearLayout smart=panel(); smart.setOrientation(LinearLayout.VERTICAL);
        smart.addView(infoLine("أعلى معدل",top==null?"—":top.name+" — "+num(top.averageNumber())));
        smart.addView(infoLine("أدنى معدل",low==null?"—":low.name+" — "+num(low.averageNumber())));
        smart.addView(infoLine("أقوى مادة",strong==null?"—":strong.subject.name+" — "+pct(strong.passRate())));
        smart.addView(infoLine("أكثر مادة تحتاج متابعة",weak==null?"—":weak.subject.name+" — "+pct(weak.passRate())));
        content.addView(smart);

        content.addView(sectionTitle("أداء المواد"));
        for(SubjectStats st:data.subjectStats()) content.addView(subjectPerformance(st));

        content.addView(sectionTitle("أفضل الطلاب"));
        int count=0; for(StudentData s:data.rankedStudents()){ if(s.averageNumber()==null)continue; content.addView(topStudentRow(++count,s)); if(count>=5)break; }
    }

    private void addStatPair(String t1,String v1,String t2,String v2){ LinearLayout r=new LinearLayout(this); r.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); r.setPadding(0,dp(4),0,dp(4)); r.addView(card(t1,v1),new LinearLayout.LayoutParams(0,dp(98),1)); Space sp=new Space(this); r.addView(sp,new LinearLayout.LayoutParams(dp(8),1)); r.addView(card(t2,v2),new LinearLayout.LayoutParams(0,dp(98),1)); content.addView(r); }
    private LinearLayout card(String title,String value){ LinearLayout c=panel(); c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER); TextView t=tv(title,11,false); t.setTextColor(MUTED); t.setGravity(Gravity.CENTER); TextView v=tv(value,24,true); v.setGravity(Gravity.CENTER); c.addView(t); c.addView(v); return c; }
    private LinearLayout panel(){ LinearLayout p=new LinearLayout(this); p.setBackgroundColor(PANEL); p.setPadding(dp(10),dp(8),dp(10),dp(8)); p.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); return p; }
    private TextView sectionTitle(String s){ TextView v=tv(s,18,true); v.setTextColor(CYAN); v.setPadding(dp(10),dp(20),dp(10),dp(8)); return v; }
    private TextView infoLine(String k,String v){ TextView x=tv(k+"  ◀  "+v,13,true); x.setTextColor(TEXT); return x; }

    private LinearLayout subjectPerformance(SubjectStats st){
        LinearLayout box=panel(); box.setOrientation(LinearLayout.VERTICAL); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2); bp.setMargins(0,0,0,dp(7)); box.setLayoutParams(bp);
        LinearLayout top=new LinearLayout(this); top.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); TextView name=tv((st.subject.ministerial?"⭐ ":"")+st.subject.name,13,true); TextView value=tv(pct(st.passRate()),13,true); value.setTextColor(st.passRate()>=70?GREEN:(st.passRate()>=50?GOLD:RED)); value.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); top.addView(name,new LinearLayout.LayoutParams(0,-2,1)); top.addView(value,new LinearLayout.LayoutParams(dp(76),-2)); box.addView(top);
        ProgressBar p=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); p.setMax(100); p.setProgress((int)Math.round(st.passRate())); p.setProgressTintList(ColorStateList.valueOf(st.passRate()>=70?GREEN:(st.passRate()>=50?GOLD:RED))); p.setProgressBackgroundTintList(ColorStateList.valueOf(PANEL3)); box.addView(p,new LinearLayout.LayoutParams(-1,dp(12)));
        TextView meta=tv("المتوسط "+num(st.average)+"  •  ناجح "+st.passed+"  •  مكمل "+st.completers+"  •  راسب "+st.failed+"  •  قرار "+st.decisions,11,false); meta.setTextColor(MUTED); box.addView(meta); box.setOnClickListener(v->showSubjectDetails(st)); return box;
    }
    private LinearLayout topStudentRow(int rank,StudentData s){ LinearLayout r=row(); addCell(r,rank+". "+s.name,3,false); addCell(r,num(s.averageNumber()),1,false); addCell(r,s.computedResult(),1,false); r.setOnClickListener(v->showStudentDetails(s)); return r; }

    private void showStudents(){
        content.removeAllViews(); Button back=button("العودة إلى الداشبورد"); back.setOnClickListener(v->showDashboard()); content.addView(back); content.addView(sectionTitle("الطلاب"));
        EditText search=new EditText(this); search.setHint("البحث عن اسم طالب..."); search.setHintTextColor(MUTED); search.setTextColor(TEXT); search.setTextDirection(View.TEXT_DIRECTION_RTL); search.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); search.setGravity(Gravity.RIGHT); search.setSingleLine(true); search.setBackgroundTintList(ColorStateList.valueOf(CYAN)); content.addView(search,new LinearLayout.LayoutParams(-1,dp(54)));
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); content.addView(list);
        Runnable render=()->renderStudents(list,search.getText().toString()); render.run();
        search.addTextChangedListener(new TextWatcher(){ public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){render.run();} public void afterTextChanged(Editable e){} });
    }
    private void renderStudents(LinearLayout list,String q){
        list.removeAllViews(); String needle=q==null?"":q.trim(); LinearLayout hdr=row(); addCell(hdr,"اسم الطالب",3,true); addCell(hdr,"النتيجة",1,true); addCell(hdr,"المعدل",1,true); list.addView(hdr);
        for(StudentData s:data.students){ if(!needle.isEmpty()&&!s.name.contains(needle))continue; LinearLayout r=row(); addCell(r,s.name,3,false); TextView status=cell(s.computedResult(),1,false); status.setTextColor(s.isPass()?GREEN:(s.isFail()?RED:(s.isCompleter()?GOLD:MUTED))); r.addView(status,new LinearLayout.LayoutParams(0,dp(56),1)); addCell(r,blank(s.average,"—"),1,false); r.setOnClickListener(v->showStudentDetails(s)); list.addView(r); }
    }
    private void showSubjects(){
        content.removeAllViews(); Button back=button("العودة إلى الداشبورد"); back.setOnClickListener(v->showDashboard()); content.addView(back); content.addView(sectionTitle("تحليل المواد"));
        for(SubjectStats st:data.subjectStats()) content.addView(subjectPerformance(st));
    }
    private void showSubjectDetails(SubjectStats st){
        content.removeAllViews(); Button back=button("العودة إلى تحليل المواد"); back.setOnClickListener(v->showSubjects()); content.addView(back); content.addView(sectionTitle(st.subject.name));
        addStatPair("المتوسط",num(st.average),"نسبة النجاح",pct(st.passRate())); addStatPair("الناجحون",String.valueOf(st.passed),"الراسبون",String.valueOf(st.failed)); addStatPair("المكملون",String.valueOf(st.completers),"القرار",String.valueOf(st.decisions)); addStatPair("الدور الثاني",String.valueOf(st.secondRound),"بيانات ناقصة",String.valueOf(st.incomplete));
        LinearLayout hdr=row(); addCell(hdr,"اسم الطالب",3,true); addCell(hdr,"المجموع",1,true); addCell(hdr,"الحالة",1,true); content.addView(hdr);
        int idx=data.subjects.indexOf(st.subject); for(StudentData s:data.students){ if(idx<0||idx>=s.grades.size())continue; GradeData g=s.grades.get(idx); Double t=g.effectiveTotal(); LinearLayout r=row(); addCell(r,s.name,3,false); addCell(r,num(t),1,false); addCell(r,g.statusLabel(),1,false); r.setOnClickListener(v->showStudentDetails(s)); content.addView(r); }
    }
    private void showStudentDetails(StudentData s){
        content.removeAllViews(); Button back=button("العودة إلى الطلاب"); back.setOnClickListener(v->showStudents()); content.addView(back); content.addView(sectionTitle(s.name));
        addStatPair("النتيجة المحسوبة",s.computedResult(),"المعدل",blank(s.average,"—")); addStatPair("المجموع",blank(s.total,"—"),"التسلسل",String.valueOf(s.serial));
        String source=s.latestSourceResult();
        if(!source.isEmpty()) addInfoPanel("نتيجة الماسترشيت — للمراجعة فقط",source);
        if(!blank(s.failedSubjects,"").isEmpty()) addInfoPanel("مواد الرسوب",s.failedSubjects);
        if(!blank(s.carry,"").isEmpty()) addInfoPanel("التحميل",s.carry);
        if(!blank(s.notes,"").isEmpty()) addInfoPanel("الملاحظات",s.notes);
        content.addView(sectionTitle("تفاصيل الدرجات"));
        for(GradeData g:s.grades) content.addView(gradeCard(g));
    }
    private void addInfoPanel(String title,String value){ LinearLayout p=panel(); p.setOrientation(LinearLayout.VERTICAL); TextView t=tv(title,12,true); t.setTextColor(GOLD); p.addView(t); TextView v=tv(value,13,false); v.setTextColor(TEXT); p.addView(v); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,dp(6)); content.addView(p,lp); }
    private LinearLayout gradeCard(GradeData g){
        LinearLayout p=panel(); p.setOrientation(LinearLayout.VERTICAL); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,dp(8)); p.setLayoutParams(lp);
        LinearLayout title=new LinearLayout(this); title.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); TextView n=tv((g.ministerial?"⭐ ":"")+g.subjectName,14,true); TextView total=tv(g.statusLabel()+" • "+num(g.effectiveTotal()),13,true); total.setTextColor(g.passesCurrentAttempt()?GREEN:(g.status()==GradeData.Status.COMPLETER?GOLD:RED)); total.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); title.addView(n,new LinearLayout.LayoutParams(0,-2,1)); title.addView(total,new LinearLayout.LayoutParams(dp(145),-2)); p.addView(title);
        LinearLayout r1=rowInside(); r1.addView(miniMetric("السعي",num(g.coursework)),new LinearLayout.LayoutParams(0,dp(62),1)); r1.addView(miniMetric("النهائي د1",num(g.firstExam)),new LinearLayout.LayoutParams(0,dp(62),1)); r1.addView(miniMetric("مجموع د1",num(g.firstTotal)),new LinearLayout.LayoutParams(0,dp(62),1)); p.addView(r1);
        LinearLayout r2=rowInside(); r2.addView(miniMetric("الدور الثاني",num(g.secondExam)),new LinearLayout.LayoutParams(0,dp(62),1)); r2.addView(miniMetric("مجموع د2",num(g.secondTotal)),new LinearLayout.LayoutParams(0,dp(62),1)); r2.addView(miniMetric("القرار",num(g.decision)),new LinearLayout.LayoutParams(0,dp(62),1)); p.addView(r2); return p;
    }
    private LinearLayout rowInside(){ LinearLayout r=new LinearLayout(this); r.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); return r; }
    private LinearLayout miniMetric(String t,String v){ LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setGravity(Gravity.CENTER); TextView a=tv(t,10,false); a.setTextColor(MUTED); a.setGravity(Gravity.CENTER); TextView b=tv(v,15,true); b.setGravity(Gravity.CENTER); p.addView(a); p.addView(b); return p; }

    private LinearLayout row(){ LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); r.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); r.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); r.setBackgroundColor(PANEL); r.setPadding(dp(2),dp(1),dp(2),dp(1)); return r; }
    private TextView cell(String text,int weight,boolean head){ TextView c=tv(text,head?11:11,head); c.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); c.setTextDirection(View.TEXT_DIRECTION_RTL); c.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); c.setBackgroundColor(head?PANEL2:PANEL); if(head)c.setTextColor(GOLD); return c; }
    private void addCell(LinearLayout row,String text,int weight,boolean head){ row.addView(cell(text,weight,head),new LinearLayout.LayoutParams(0,dp(head?48:56),weight)); }
    private String joinMeta(){ List<String> a=new ArrayList<>(); if(!data.department.isEmpty())a.add(data.department); if(!data.studyType.isEmpty())a.add(data.studyType); if(!data.stage.isEmpty())a.add(data.stage); if(!data.semester.isEmpty())a.add(data.semester); if(!data.academicYear.isEmpty())a.add(data.academicYear); return android.text.TextUtils.join(" • ",a); }
    private String blank(String x,String d){ return x==null||x.trim().isEmpty()?d:x; }
    private String num(Double d){ if(d==null)return "—"; return Math.abs(d-Math.rint(d))<0.000001?String.valueOf((int)Math.rint(d)):String.format(Locale.US,"%.1f",d); }
    private String num(double d){ return Math.abs(d-Math.rint(d))<0.000001?String.valueOf((int)Math.rint(d)):String.format(Locale.US,"%.1f",d); }
    private String pct(double d){ return String.format(Locale.US,"%.1f%%",d); }
    private int dp(int x){ return (int)(x*getResources().getDisplayMetrics().density+0.5f); }
}
