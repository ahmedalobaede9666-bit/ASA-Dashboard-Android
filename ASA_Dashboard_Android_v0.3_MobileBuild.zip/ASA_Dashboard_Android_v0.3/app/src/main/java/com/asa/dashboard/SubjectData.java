package com.asa.dashboard;

public class SubjectData {
    public String name;
    public int startCol;
    public int endCol;
    public String unit;
    public boolean ministerial;
    public SubjectData(String name,int startCol,int endCol,String unit,boolean ministerial){
        this.name=name; this.startCol=startCol; this.endCol=endCol; this.unit=unit; this.ministerial=ministerial;
    }
}
