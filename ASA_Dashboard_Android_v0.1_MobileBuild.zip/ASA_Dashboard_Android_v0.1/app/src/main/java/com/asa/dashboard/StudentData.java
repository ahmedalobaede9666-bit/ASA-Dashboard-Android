package com.asa.dashboard;
import java.util.*;
public class StudentData {
    public int serial;
    public String name="";
    public String result="";
    public String failedSubjects="";
    public String carry="";
    public String average="";
    public String total="";
    public String notes="";
    public final List<GradeData> grades = new ArrayList<>();
    public boolean isPass(){ String x=result==null?"":result.trim(); return x.contains("ناجح") || x.contains("Pass"); }
    public boolean isFail(){ String x=result==null?"":result.trim(); return x.contains("راسب") || x.contains("Fail"); }
}
