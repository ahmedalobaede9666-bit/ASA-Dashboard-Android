package com.asa.dashboard;

public class GradeData {
    public String subjectName="";
    public Double coursework;
    public Double firstExam;
    public Double firstTotal;
    public Double secondExam;
    public Double secondTotal;
    public Double decision;
    public boolean ministerial;
    public Double effectiveTotal(){
        Double base = secondTotal!=null ? secondTotal : firstTotal;
        if(base==null) return null;
        return base + (decision==null?0:decision);
    }
}
