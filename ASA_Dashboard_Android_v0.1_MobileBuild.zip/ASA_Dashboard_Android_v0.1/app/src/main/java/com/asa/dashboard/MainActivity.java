package com.asa.dashboard;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final int PICK_XLSX=1001;
    private final int BG=Color.rgb(8,17,31), PANEL=Color.rgb(14,26,44), PANEL2=Color.rgb(18,35,58), TEXT=Color.rgb(238,247,255), MUTED=Color.rgb(143,168,191), CYAN=Color.rgb(50,216,255), GOLD=Color.rgb(242,198,109);
    private LinearLayout root, content;
    private MasterSheetData data;

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG); buildShell(); showWelcome(); }
    private TextView tv(String t,int sp,boolean bold){ TextView v=new TextView(this); v.setText(t); v.setTextColor(TEXT); v.setTextSize(sp); v.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); v.setTextDirection(View.TEXT_DIRECTION_RTL); v.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); v.setPadding(dp(12),dp(8),dp(12),dp(8)); return v; }
    private void buildShell(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); root.setBackgroundColor(BG); setContentView(root);
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); top.setPadding(dp(14),dp(10),dp(14),dp(10)); top.setBackgroundColor(PANEL);
        ImageView icon=new ImageView(this); icon.setImageResource(com.asa.dashboard.R.drawable.asa_icon); top.addView(icon,new LinearLayout.LayoutParams(dp(54),dp(54)));
        LinearLayout titles=new LinearLayout(this); titles.setOrientation(LinearLayout.VERTICAL); titles.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); TextView t=tv("ASA Dashboard",20,true), s=tv("تحويل الماسترشيت إلى لوحة تحليل عربية",11,false); s.setTextColor(MUTED); titles.addView(t); titles.addView(s); LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1); top.addView(titles,tp); root.addView(top);
        ScrollView sc=new ScrollView(this); sc.setFillViewport(true); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); content.setPadding(dp(12),dp(12),dp(12),dp(24)); sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
    }
    private Button button(String t){ Button b=new Button(this); b.setText(t); b.setTextDirection(View.TEXT_DIRECTION_RTL); b.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); b.setTextColor(TEXT); b.setBackgroundColor(PANEL2); b.setAllCaps(false); b.setTextSize(15); return b; }
    private void showWelcome(){ content.removeAllViews(); TextView h=tv("مرحباً بك في ASA Dashboard",24,true); content.addView(h); TextView p=tv("اختر ملف الماسترشيت بصيغة XLSX من هاتفك. سيقرأ التطبيق عدد الطلاب والمواد تلقائياً ويعرض النتائج باتجاه عربي كامل من اليمين إلى اليسار.",14,false); p.setTextColor(MUTED); content.addView(p); Button importBtn=button("استيراد ملف الماسترشيت"); importBtn.setOnClickListener(v->pickFile()); content.addView(importBtn,new LinearLayout.LayoutParams(-1,dp(58))); }
    private void pickFile(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"); startActivityForResult(i,PICK_XLSX); }
    @Override protected void onActivityResult(int r,int code,Intent i){ super.onActivityResult(r,code,i); if(r==PICK_XLSX&&code==RESULT_OK&&i!=null){ Uri u=i.getData(); if(u!=null) loadFile(u); } }
    private void loadFile(Uri u){ content.removeAllViews(); content.addView(tv("جارٍ تحليل الماسترشيت...",18,true)); new Thread(()->{ try{ MasterSheetData d=new ExcelMasterSheetReader().read(this,u); runOnUiThread(()->{data=d; showDashboard();}); }catch(Exception e){runOnUiThread(()->showError(e));}}).start(); }
    private void showError(Exception e){ content.removeAllViews(); TextView x=tv("تعذر قراءة الملف",22,true); x.setTextColor(Color.rgb(255,127,145)); content.addView(x); TextView d=tv(e.getMessage()==null?e.toString():e.getMessage(),13,false); d.setTextColor(MUTED); content.addView(d); Button b=button("اختيار ملف آخر"); b.setOnClickListener(v->pickFile()); content.addView(b); }
    private void showDashboard(){
        content.removeAllViews();
        TextView college=tv(blank(data.college,"الكلية"),22,true); content.addView(college); TextView meta=tv(joinMeta(),13,false); meta.setTextColor(MUTED); content.addView(meta);
        LinearLayout actions=new LinearLayout(this); actions.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); Button students=button("الطلاب"), subjects=button("المواد"), another=button("ملف آخر"); students.setOnClickListener(v->showStudents()); subjects.setOnClickListener(v->showSubjects()); another.setOnClickListener(v->pickFile()); actions.addView(students,new LinearLayout.LayoutParams(0,dp(52),1)); actions.addView(subjects,new LinearLayout.LayoutParams(0,dp(52),1)); actions.addView(another,new LinearLayout.LayoutParams(0,dp(52),1)); content.addView(actions);
        LinearLayout cards=new LinearLayout(this); cards.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); cards.addView(card("الطلاب",String.valueOf(data.students.size())),new LinearLayout.LayoutParams(0,dp(105),1)); cards.addView(card("المواد",String.valueOf(data.subjects.size())),new LinearLayout.LayoutParams(0,dp(105),1)); cards.addView(card("وزارية ⭐",String.valueOf(data.ministerialCount())),new LinearLayout.LayoutParams(0,dp(105),1)); content.addView(cards);
        LinearLayout cards2=new LinearLayout(this); cards2.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); cards2.addView(card("ناجح",String.valueOf(data.passedCount())),new LinearLayout.LayoutParams(0,dp(105),1)); cards2.addView(card("راسب",String.valueOf(data.failedCount())),new LinearLayout.LayoutParams(0,dp(105),1)); cards2.addView(card("بدون نتيجة",String.valueOf(data.pendingCount())),new LinearLayout.LayoutParams(0,dp(105),1)); content.addView(cards2);
        content.addView(sectionTitle("نظرة على المواد")); int n=Math.min(6,data.subjects.size()); for(int i=0;i<n;i++){ SubjectData s=data.subjects.get(i); TextView r=tv((s.ministerial?"⭐ ":"")+s.name+"    "+s.unit,14,true); r.setBackgroundColor(PANEL); content.addView(r,new LinearLayout.LayoutParams(-1,dp(54))); }
    }
    private LinearLayout card(String title,String value){ LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER); c.setBackgroundColor(PANEL); c.setPadding(dp(5),dp(6),dp(5),dp(6)); TextView t=tv(title,11,false); t.setTextColor(MUTED); t.setGravity(Gravity.CENTER); TextView v=tv(value,25,true); v.setGravity(Gravity.CENTER); c.addView(t); c.addView(v); return c; }
    private TextView sectionTitle(String s){ TextView v=tv(s,18,true); v.setTextColor(CYAN); v.setPadding(dp(12),dp(20),dp(12),dp(8)); return v; }
    private void showStudents(){ content.removeAllViews(); Button back=button("العودة إلى الداشبورد"); back.setOnClickListener(v->showDashboard()); content.addView(back); content.addView(sectionTitle("قائمة الطلاب"));
        // Header deliberately RTL: student name is the first column visually on the right.
        LinearLayout hdr=row(); addCell(hdr,"اسم الطالب",2,true); addCell(hdr,"النتيجة",1,true); addCell(hdr,"المعدل",1,true); content.addView(hdr);
        for(StudentData s:data.students){ LinearLayout r=row(); addCell(r,s.name,2,false); addCell(r,blank(s.result,"—"),1,false); addCell(r,blank(s.average,"—"),1,false); r.setOnClickListener(v->showStudentDetails(s)); content.addView(r); }
    }
    private void showSubjects(){ content.removeAllViews(); Button back=button("العودة إلى الداشبورد"); back.setOnClickListener(v->showDashboard()); content.addView(back); content.addView(sectionTitle("تحليل المواد")); LinearLayout hdr=row(); addCell(hdr,"اسم المادة",3,true); addCell(hdr,"الوحدة",1,true); addCell(hdr,"النوع",1,true); content.addView(hdr); for(SubjectData s:data.subjects){ LinearLayout r=row(); addCell(r,s.name,3,false); addCell(r,blank(s.unit,"—"),1,false); addCell(r,s.ministerial?"وزارية ⭐":"داخلية",1,false); content.addView(r); } }
    private void showStudentDetails(StudentData s){ content.removeAllViews(); Button back=button("العودة إلى الطلاب"); back.setOnClickListener(v->showStudents()); content.addView(back); content.addView(sectionTitle(s.name)); TextView m=tv("النتيجة: "+blank(s.result,"—")+"    المعدل: "+blank(s.average,"—")+"    المجموع: "+blank(s.total,"—"),14,true); content.addView(m); LinearLayout hdr=row(); addCell(hdr,"المادة",2,true); addCell(hdr,"السعي",1,true); addCell(hdr,"د1",1,true); addCell(hdr,"د2",1,true); addCell(hdr,"القرار",1,true); addCell(hdr,"المجموع",1,true); content.addView(hdr); for(GradeData g:s.grades){ LinearLayout r=row(); addCell(r,g.subjectName,2,false); addCell(r,n(g.coursework),1,false); addCell(r,n(g.firstExam),1,false); addCell(r,n(g.secondExam),1,false); addCell(r,n(g.decision),1,false); addCell(r,n(g.effectiveTotal()),1,false); content.addView(r); } }
    private LinearLayout row(){ LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); r.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); r.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); r.setBackgroundColor(PANEL); r.setPadding(dp(2),dp(1),dp(2),dp(1)); return r; }
    private void addCell(LinearLayout row,String text,int weight,boolean head){ TextView c=tv(text,head?12:11,head); c.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); c.setTextDirection(View.TEXT_DIRECTION_RTL); c.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); c.setBackgroundColor(head?PANEL2:PANEL); if(head)c.setTextColor(GOLD); row.addView(c,new LinearLayout.LayoutParams(0,dp(head?48:54),weight)); }
    private String joinMeta(){ List<String> a=new ArrayList<>(); if(!data.department.isEmpty())a.add(data.department); if(!data.studyType.isEmpty())a.add(data.studyType); if(!data.stage.isEmpty())a.add(data.stage); if(!data.semester.isEmpty())a.add(data.semester); if(!data.academicYear.isEmpty())a.add(data.academicYear); return android.text.TextUtils.join(" • ",a); }
    private String blank(String x,String d){ return x==null||x.trim().isEmpty()?d:x; } private String n(Double d){ if(d==null)return "—"; return d==Math.rint(d)?String.valueOf(d.intValue()):String.format(Locale.US,"%.1f",d); }
    private int dp(int x){ return (int)(x*getResources().getDisplayMetrics().density+0.5f); }
}
