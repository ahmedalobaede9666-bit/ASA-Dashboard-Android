package com.asa.dashboard;

import java.util.*;

public class MasterSheetData {
    public String college = "";
    public String department = "";
    public String studyType = "";
    public String stage = "";
    public String semester = "";
    public String academicYear = "";
    public final List<SubjectData> subjects = new ArrayList<>();
    public final List<StudentData> students = new ArrayList<>();

    public int passedCount() { int n=0; for(StudentData s: students) if(s.isPass()) n++; return n; }
    public int failedCount() { int n=0; for(StudentData s: students) if(s.isFail()) n++; return n; }
    public int pendingCount() { return Math.max(0, students.size()-passedCount()-failedCount()); }
    public int ministerialCount() { int n=0; for(SubjectData s: subjects) if(s.ministerial) n++; return n; }
}
