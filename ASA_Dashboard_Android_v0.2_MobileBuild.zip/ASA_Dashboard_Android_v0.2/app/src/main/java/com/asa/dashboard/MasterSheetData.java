package com.asa.dashboard;

import java.util.*;

public class MasterSheetData {
    public String college = "";
    public String department = "";
    public String studyType = "";
    public String stage = "";
    public String semester = "";
    public String academicYear = "";
    public final List<SubjectData> subjects = new ArrayList<>();
    public final List<StudentData> students = new ArrayList<>();

    public int passedCount() { int n=0; for(StudentData s: students) if(s.isPass()) n++; return n; }
    public int failedCount() { int n=0; for(StudentData s: students) if(s.isFail()) n++; return n; }
    public int pendingCount() { return Math.max(0, students.size()-passedCount()-failedCount()); }
    public int ministerialCount() { int n=0; for(SubjectData s: subjects) if(s.ministerial) n++; return n; }
    public int decisionStudentsCount(){ int n=0; for(StudentData s:students) if(s.hasDecision())n++; return n; }
    public int secondRoundStudentsCount(){ int n=0; for(StudentData s:students) if(s.hasSecondRound())n++; return n; }
    public double passRate(){ return students.isEmpty()?0:(passedCount()*100.0/students.size()); }
    public double averageOfAverages(){ double sum=0; int n=0; for(StudentData s:students){ Double v=s.averageNumber(); if(v!=null){sum+=v;n++;} } return n==0?0:sum/n; }
    public StudentData topStudent(){ StudentData best=null; double bestV=-1; for(StudentData s:students){ Double v=s.averageNumber(); if(v!=null&&v>bestV){bestV=v;best=s;} } return best; }
    public StudentData lowestStudent(){ StudentData best=null; double bestV=999; for(StudentData s:students){ Double v=s.averageNumber(); if(v!=null&&v<bestV){bestV=v;best=s;} } return best; }
    public List<StudentData> rankedStudents(){ List<StudentData> a=new ArrayList<>(students); Collections.sort(a,(x,y)->Double.compare(y.averageNumber()==null?-1:y.averageNumber(),x.averageNumber()==null?-1:x.averageNumber())); return a; }

    public List<SubjectStats> subjectStats(){
        List<SubjectStats> out=new ArrayList<>();
        for(int i=0;i<subjects.size();i++){
            SubjectStats st=new SubjectStats(); st.subject=subjects.get(i); double sum=0;
            for(StudentData s:students){
                if(i>=s.grades.size())continue; GradeData g=s.grades.get(i); Double t=g.effectiveTotal();
                if(t!=null){ st.graded++; sum+=t; if(t>=50)st.passed++; else st.failed++; }
                if(g.decision!=null&&g.decision>0)st.decisions++;
                if(g.secondExam!=null)st.secondRound++;
            }
            st.average=st.graded==0?0:sum/st.graded; out.add(st);
        }
        return out;
    }
    public SubjectStats weakestSubject(){ SubjectStats w=null; for(SubjectStats s:subjectStats()) if(s.graded>0&&(w==null||s.passRate()<w.passRate()))w=s; return w; }
    public SubjectStats strongestSubject(){ SubjectStats w=null; for(SubjectStats s:subjectStats()) if(s.graded>0&&(w==null||s.passRate()>w.passRate()))w=s; return w; }
}
