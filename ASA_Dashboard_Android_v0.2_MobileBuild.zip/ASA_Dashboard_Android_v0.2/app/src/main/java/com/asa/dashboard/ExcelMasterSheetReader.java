package com.asa.dashboard;

import android.content.Context;
import android.net.Uri;
import java.io.*;
import java.util.*;
import java.util.zip.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;

/** Lightweight XLSX reader tailored to the fixed ASA master-sheet template. */
public class ExcelMasterSheetReader {
    private final Map<String,String> entries = new HashMap<>();
    private final List<String> sharedStrings = new ArrayList<>();
    private final Map<String,String> cells = new HashMap<>();
    private final List<String> mergeRefs = new ArrayList<>();

    public MasterSheetData read(Context context, Uri uri) throws Exception {
        entries.clear(); sharedStrings.clear(); cells.clear(); mergeRefs.clear();
        InputStream raw = context.getContentResolver().openInputStream(uri);
        if(raw==null) throw new IOException("تعذر فتح ملف الماسترشيت");
        try(InputStream in=raw; ZipInputStream zin=new ZipInputStream(in)){
            ZipEntry e; byte[] buf=new byte[8192];
            while((e=zin.getNextEntry())!=null){
                ByteArrayOutputStream out=new ByteArrayOutputStream(); int n;
                while((n=zin.read(buf))>0) out.write(buf,0,n);
                entries.put(e.getName(), out.toString("UTF-8"));
            }
        }
        if(entries.containsKey("xl/sharedStrings.xml")) parseShared(entries.get("xl/sharedStrings.xml"));
        String sheet = entries.get("xl/worksheets/sheet1.xml");
        if(sheet==null) throw new IllegalArgumentException("لم يتم العثور على ورقة العمل الأولى داخل ملف XLSX");
        parseSheet(sheet);
        MasterSheetData model=buildModel();
        if(model.subjects.isEmpty() && model.students.isEmpty())
            throw new IllegalArgumentException("تم فتح الملف، لكن لم يتم التعرف على قالب الماسترشيت. تأكد أن الملف صادر من نفس القالب المعتمد.");
        return model;
    }

    private Document doc(String xml) throws Exception {
        DocumentBuilderFactory f=DocumentBuilderFactory.newInstance();
        f.setNamespaceAware(true);
        try { f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true); } catch(Exception ignored){}
        return f.newDocumentBuilder().parse(new ByteArrayInputStream(xml.getBytes("UTF-8")));
    }
    private NodeList nodes(Document d,String local){ return d.getElementsByTagNameNS("*",local); }
    private NodeList nodes(Element e,String local){ return e.getElementsByTagNameNS("*",local); }
    private String localName(Node n){ String s=n.getLocalName(); if(s!=null)return s; String q=n.getNodeName(); int p=q.indexOf(':'); return p>=0?q.substring(p+1):q; }

    private void parseShared(String xml) throws Exception {
        NodeList si=nodes(doc(xml),"si");
        for(int i=0;i<si.getLength();i++) sharedStrings.add(allText(si.item(i)));
    }
    private String allText(Node n){
        StringBuilder b=new StringBuilder(); NodeList kids=n.getChildNodes();
        for(int i=0;i<kids.getLength();i++){
            Node k=kids.item(i);
            if("t".equals(localName(k))) b.append(k.getTextContent());
            else b.append(allText(k));
        }
        return b.toString();
    }
    private void parseSheet(String xml) throws Exception {
        Document d=doc(xml); NodeList cs=nodes(d,"c");
        for(int i=0;i<cs.getLength();i++){
            Element c=(Element)cs.item(i); String ref=c.getAttribute("r"), type=c.getAttribute("t");
            String val=""; NodeList vs=nodes(c,"v");
            if(vs.getLength()>0){
                val=vs.item(0).getTextContent();
                if("s".equals(type)){
                    try{ int idx=Integer.parseInt(val); if(idx>=0&&idx<sharedStrings.size()) val=sharedStrings.get(idx); }catch(Exception ignored){}
                }
            } else {
                NodeList is=nodes(c,"is"); if(is.getLength()>0) val=allText(is.item(0));
            }
            cells.put(ref, val==null?"":val.trim());
        }
        NodeList merges=nodes(d,"mergeCell");
        for(int i=0;i<merges.getLength();i++) mergeRefs.add(((Element)merges.item(i)).getAttribute("ref"));
    }
    private MasterSheetData buildModel(){
        MasterSheetData m=new MasterSheetData();
        m.college = stripLabel(val("A1"),"الكلية");
        m.department=stripLabel(val("A5"),"القسم");
        m.studyType=stripLabel(val("A6"),"نوع الدراسة");
        m.stage=stripLabel(val("A7"),"المرحلة");
        m.semester=stripLabel(val("A8"),"الفصل");
        m.academicYear=stripLabel(val("A9"),"السنة الدراسية");

        int c=3;
        while(true){
            String ref=coord(c,11); String merge=findMergeFor(ref);
            if(merge==null) break;
            int[] bounds=mergeBounds(merge); if(bounds[2]-bounds[0]+1!=3) break;
            String name=val(coord(bounds[0],11)); if(name.isEmpty()) break;
            String unit=stripLabel(val(coord(bounds[0],13)),"الوحدة");
            boolean ministerial=name.contains("⭐") || name.contains("*");
            m.subjects.add(new SubjectData(name,bounds[0],bounds[2],unit,ministerial)); c=bounds[2]+1;
        }
        int resultCol=c, failedCol=c+1, carryCol=c+2, avgCol=c+3, totalCol=c+4, notesCol=c+5;
        int row=14, guard=0;
        while(row<5000 && guard++<5000){
            String a=val(coord(1,row)), b=val(coord(2,row));
            String mr=findMergeFor(coord(1,row));
            if(mr!=null){ int[] mb=mergeBounds(mr); if(mb[0]==1 && mb[2]>=20){ row=mb[3]+1; continue; } }
            if(a.isEmpty() && b.isEmpty()) { if(emptyAround(row)) break; row++; continue; }
            int serial=parseInt(a,-1); if(serial<0){ row++; continue; }
            StudentData s=new StudentData(); s.serial=serial; s.name=b;
            for(SubjectData sub:m.subjects){
                GradeData g=new GradeData(); g.subjectName=sub.name; g.ministerial=sub.ministerial;
                g.decision=num(val(coord(sub.endCol,row)));
                g.coursework=num(val(coord(sub.startCol,row+1)));
                g.firstExam=num(val(coord(sub.startCol+1,row+1)));
                g.firstTotal=num(val(coord(sub.endCol,row+1)));
                g.secondExam=num(val(coord(sub.startCol+1,row+2)));
                g.secondTotal=num(val(coord(sub.endCol,row+2)));
                s.grades.add(g);
            }
            s.result=val(coord(resultCol,row+1));
            s.failedSubjects=val(coord(failedCol,row+1));
            s.carry=firstNonEmpty(val(coord(carryCol,row)),val(coord(carryCol,row+1)),val(coord(carryCol,row+2)));
            s.average=val(coord(avgCol,row+1)); s.total=val(coord(totalCol,row+1)); s.notes=val(coord(notesCol,row+1));
            m.students.add(s); row+=3;
        }
        return m;
    }
    private String stripLabel(String s,String label){
        if(s==null)return ""; String x=s.trim();
        x=x.replaceFirst("^"+java.util.regex.Pattern.quote(label)+"\\s*[:：]\\s*","");
        return x.trim();
    }
    private boolean emptyAround(int row){ for(int r=row;r<row+6;r++) if(!val("A"+r).isEmpty()||!val("B"+r).isEmpty()) return false; return true; }
    private String firstNonEmpty(String... xs){ for(String x:xs) if(x!=null&&!x.trim().isEmpty()) return x; return ""; }
    private String val(String ref){ return cells.getOrDefault(ref,""); }
    private Double num(String x){ if(x==null) return null; String clean=x.replaceAll("[^0-9.\\-]",""); if(clean.isEmpty()) return null; try{return Double.parseDouble(clean);}catch(Exception e){return null;} }
    private int parseInt(String x,int d){ try{return (int)Math.round(Double.parseDouble(x));}catch(Exception e){return d;} }
    private String findMergeFor(String ref){ int[] p=parseCoord(ref); for(String m:mergeRefs){ int[] b=mergeBounds(m); if(p[0]>=b[0]&&p[0]<=b[2]&&p[1]>=b[1]&&p[1]<=b[3]) return m; } return null; }
    private int[] mergeBounds(String m){ String[] a=m.split(":"); int[] p1=parseCoord(a[0]),p2=parseCoord(a.length>1?a[1]:a[0]); return new int[]{p1[0],p1[1],p2[0],p2[1]}; }
    private int[] parseCoord(String ref){ int i=0,col=0; while(i<ref.length()&&Character.isLetter(ref.charAt(i))){ col=col*26+(Character.toUpperCase(ref.charAt(i))-'A'+1); i++; } int row=Integer.parseInt(ref.substring(i)); return new int[]{col,row}; }
    private String coord(int col,int row){ StringBuilder s=new StringBuilder(); while(col>0){ int r=(col-1)%26; s.insert(0,(char)('A'+r)); col=(col-1)/26;} return s.toString()+row; }
}
