package com.asa.dashboard;

public class SubjectStats {
    public SubjectData subject;
    public int graded;
    public int passed;
    public int failed;
    public int decisions;
    public int secondRound;
    public double average;
    public double passRate(){ return graded==0?0:(passed*100.0/graded); }
}
