package com.asa.dashboard;
import java.util.*;
public class StudentData {
    public int serial;
    public String name="";
    public String result="";
    public String failedSubjects="";
    public String carry="";
    public String average="";
    public String total="";
    public String notes="";
    public final List<GradeData> grades = new ArrayList<>();
    public boolean isPass(){ String x=result==null?"":result.trim(); return x.contains("ناجح") || x.toLowerCase(Locale.US).contains("pass"); }
    public boolean isFail(){ String x=result==null?"":result.trim(); return x.contains("راسب") || x.toLowerCase(Locale.US).contains("fail"); }
    public boolean hasDecision(){ for(GradeData g:grades)if(g.decision!=null&&g.decision>0)return true; return false; }
    public boolean hasSecondRound(){ for(GradeData g:grades)if(g.secondExam!=null)return true; return false; }
    public Double averageNumber(){ return number(average); }
    public Double totalNumber(){ return number(total); }
    private Double number(String x){ if(x==null)return null; String c=x.replaceAll("[^0-9.\\-]",""); if(c.isEmpty())return null; try{return Double.parseDouble(c);}catch(Exception e){return null;} }
}
