(function(global){
  'use strict';

  const SUMMARY_KEYS = {
    result: ['النتيجة','نتيجة'],
    failed: ['مواد الرسوب','المواد الراسبة','مواد راسبة','الرسوب'],
    carry: ['التحميل','تحميل'],
    average: ['المعدل','معدل'],
    total: ['المجموع','المجموع الكلي','مجموع'],
    notes: ['الملاحظات','ملاحظات']
  };

  function requireJSZip(){
    const z = global.JSZip || (typeof JSZip !== 'undefined' ? JSZip : null);
    if(!z) throw new Error('مكتبة قراءة ملفات Excel غير متاحة. أعد فتح التطبيق ثم حاول مرة أخرى.');
    return z;
  }

  function xmlDoc(text){
    text = String(text??'').replace(/^\uFEFF/,'').replace(/^\s+(?=<\?xml)/,'');
    const d = new DOMParser().parseFromString(text, 'application/xml');
    const err = d.getElementsByTagName('parsererror');
    if(err && err.length) throw new Error('تعذر تحليل أحد ملفات XML داخل ملف Excel.');
    return d;
  }

  function elements(node, local){
    if(node.getElementsByTagNameNS){
      const n = node.getElementsByTagNameNS('*', local);
      if(n && n.length) return Array.from(n);
    }
    return Array.from(node.getElementsByTagName('*')).filter(x => (x.localName || x.nodeName.split(':').pop()) === local);
  }

  function allText(node){
    return elements(node, 't').map(x => x.textContent || '').join('');
  }

  function attrLocal(el, local){
    for(const a of Array.from(el.attributes || [])){
      if((a.localName || a.name.split(':').pop()) === local) return a.value;
    }
    return '';
  }

  function normalizePath(base, target){
    if(!target) return '';
    if(target.startsWith('/')) return target.replace(/^\//,'');
    const parts = (base + '/' + target).split('/');
    const out=[];
    for(const p of parts){
      if(!p || p === '.') continue;
      if(p === '..') out.pop(); else out.push(p);
    }
    return out.join('/');
  }

  function colToLetters(col){
    let s='';
    while(col>0){ const r=(col-1)%26; s=String.fromCharCode(65+r)+s; col=Math.floor((col-1)/26); }
    return s;
  }
  function coord(col,row){ return colToLetters(col)+row; }
  function parseCoord(ref){
    const m=String(ref||'').match(/^([A-Za-z]+)(\d+)$/);
    if(!m) return {col:0,row:0};
    let c=0; for(const ch of m[1].toUpperCase()) c=c*26+(ch.charCodeAt(0)-64);
    return {col:c,row:Number(m[2])};
  }
  function parseRange(ref){
    const [a,b=a]=String(ref||'').split(':');
    const p1=parseCoord(a), p2=parseCoord(b);
    return {c1:p1.col,r1:p1.row,c2:p2.col,r2:p2.row,ref:String(ref||'')};
  }

  function norm(s){
    return String(s??'').normalize('NFKC').replace(/[\u064B-\u065F\u0670]/g,'').replace(/ـ/g,'').replace(/\s+/g,' ').trim();
  }
  function numeric(v){
    const s=String(v??'').replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
    const m=s.replace(/,/g,'.').match(/-?\d+(?:\.\d+)?/);
    if(!m) return null;
    const n=Number(m[0]); return Number.isFinite(n)?n:null;
  }
  function integer(v){ const n=numeric(v); return n===null?null:Math.round(n); }
  function nonempty(...xs){ for(const x of xs){ if(String(x??'').trim()) return String(x).trim(); } return ''; }
  function stripLabel(value,label){
    let x=String(value??'').trim();
    const l=norm(label);
    const n=norm(x);
    if(n.startsWith(l)){
      x=x.replace(new RegExp('^\\s*'+escapeRegExp(label)+'\\s*[:：]?\\s*','u'),'');
    }
    return x.trim();
  }
  function escapeRegExp(s){ return String(s).replace(/[.*+?^${}()|[\]\\]/g,'\\$&'); }
  function isSummaryHeader(s){
    const n=norm(s);
    return Object.values(SUMMARY_KEYS).flat().some(k=>n===norm(k));
  }
  function matchesAny(s,arr){ const n=norm(s); return arr.some(k=>n.includes(norm(k))); }

  async function readText(zip,path){
    const f=zip.file(path); if(!f) return null; return await f.async('string');
  }

  async function sharedStrings(zip){
    const text=await readText(zip,'xl/sharedStrings.xml');
    if(!text) return [];
    const d=xmlDoc(text);
    return elements(d,'si').map(si=>allText(si));
  }

  async function workbookSheetPaths(zip){
    const wbText=await readText(zip,'xl/workbook.xml');
    const relText=await readText(zip,'xl/_rels/workbook.xml.rels');
    if(!wbText || !relText){
      return Object.keys(zip.files).filter(x=>/^xl\/worksheets\/sheet\d+\.xml$/i.test(x)).sort();
    }
    const wb=xmlDoc(wbText), rel=xmlDoc(relText);
    const relMap=new Map();
    for(const r of elements(rel,'Relationship')) relMap.set(r.getAttribute('Id')||attrLocal(r,'Id'), r.getAttribute('Target')||attrLocal(r,'Target'));
    const out=[];
    for(const sh of elements(wb,'sheet')){
      const rid=sh.getAttribute('r:id') || attrLocal(sh,'id');
      const target=relMap.get(rid);
      if(target) out.push({name:sh.getAttribute('name')||'', path:normalizePath('xl',target)});
    }
    if(!out.length) return Object.keys(zip.files).filter(x=>/^xl\/worksheets\/sheet\d+\.xml$/i.test(x)).sort().map(path=>({name:'',path}));
    return out;
  }

  async function parseSheet(zip,path,shared){
    const text=await readText(zip,path);
    if(!text) throw new Error('تعذر فتح ورقة العمل داخل ملف Excel.');
    const d=xmlDoc(text), cells=new Map(), merges=[];
    let maxRow=0,maxCol=0;
    for(const c of elements(d,'c')){
      const ref=c.getAttribute('r'); if(!ref) continue;
      const p=parseCoord(ref); maxRow=Math.max(maxRow,p.row); maxCol=Math.max(maxCol,p.col);
      const type=c.getAttribute('t')||'';
      let val='';
      const vs=elements(c,'v');
      if(vs.length){
        val=vs[0].textContent||'';
        if(type==='s'){
          const i=Number(val); val=Number.isInteger(i)&&i>=0&&i<shared.length?shared[i]:val;
        } else if(type==='b') val=val==='1'?'TRUE':'FALSE';
      } else {
        const is=elements(c,'is'); if(is.length) val=allText(is[0]);
      }
      cells.set(ref,String(val??'').trim());
    }
    for(const mc of elements(d,'mergeCell')){
      const ref=mc.getAttribute('ref'); if(ref) merges.push(parseRange(ref));
    }
    const sheet={path,cells,merges,maxRow,maxCol};
    sheet.findMerge=function(ref){ const p=parseCoord(ref); return merges.find(m=>p.col>=m.c1&&p.col<=m.c2&&p.row>=m.r1&&p.row<=m.r2)||null; };
    sheet.valueAt=function(ref){
      const direct=cells.get(ref); if(direct!==undefined && direct!=='') return direct;
      const m=sheet.findMerge(ref); if(m){ const top=coord(m.c1,m.r1); return cells.get(top)||''; }
      return direct||'';
    };
    return sheet;
  }

  function detectSubjects(sheet){
    const out=[]; let c=3; const limit=Math.max(sheet.maxCol||0,60);
    while(c<=limit){
      const header=sheet.valueAt(coord(c,11));
      if(!header || isSummaryHeader(header)) break;
      const m=sheet.findMerge(coord(c,11));
      let start=c,end=c+2;
      if(m && m.r1<=11 && m.r2>=11){ start=m.c1; end=m.c2; }
      if(end-start+1!==3) break;
      const name=sheet.valueAt(coord(start,11));
      if(!name || isSummaryHeader(name)) break;
      const unit=stripLabel(sheet.valueAt(coord(start,13)),'الوحدة');
      out.push({name,displayName:name.replace(/\s*[⭐*]+\s*/g,' ').replace(/\s+/g,' ').trim(),startCol:start,endCol:end,unit,ministerial:/[⭐*]/.test(name)});
      c=end+1;
    }
    return {subjects:out,nextCol:c};
  }

  function detectSummaryCols(sheet,start){
    const found={};
    for(let c=start;c<=Math.min((sheet.maxCol||start)+3,start+16);c++){
      const h=sheet.valueAt(coord(c,11)); if(!h) continue;
      if(found.result===undefined && matchesAny(h,SUMMARY_KEYS.result)) found.result=c;
      else if(found.failed===undefined && matchesAny(h,SUMMARY_KEYS.failed)) found.failed=c;
      else if(found.carry===undefined && matchesAny(h,SUMMARY_KEYS.carry)) found.carry=c;
      else if(found.average===undefined && matchesAny(h,SUMMARY_KEYS.average)) found.average=c;
      else if(found.notes===undefined && matchesAny(h,SUMMARY_KEYS.notes)) found.notes=c;
      else if(found.total===undefined && matchesAny(h,SUMMARY_KEYS.total)) found.total=c;
    }
    return {
      result:found.result??start,
      failed:found.failed??start+1,
      carry:found.carry??start+2,
      average:found.average??start+3,
      total:found.total??start+4,
      notes:found.notes??start+5
    };
  }

  function candidateScore(sheet){
    let score=0;
    for(const r of [1,5,6,7,8,9]) if(sheet.valueAt('A'+r)) score++;
    const ds=detectSubjects(sheet); score+=ds.subjects.length*3;
    if(ds.subjects.length) score+=10;
    if(integer(sheet.valueAt('A14'))!==null && sheet.valueAt('B14')) score+=10;
    for(let c=3;c<=Math.min(sheet.maxCol||30,40);c++) if(matchesAny(sheet.valueAt(coord(c,11)),SUMMARY_KEYS.result)) score+=4;
    return score;
  }

  function prepareGrade(g){
    g.decision=Number.isFinite(g.decision)?g.decision:null;
    g.coursework=Number.isFinite(g.coursework)?g.coursework:null;
    g.firstExam=Number.isFinite(g.firstExam)?g.firstExam:null;
    g.firstTotal=Number.isFinite(g.firstTotal)?g.firstTotal:null;
    g.secondExam=Number.isFinite(g.secondExam)?g.secondExam:null;
    g.secondTotal=Number.isFinite(g.secondTotal)?g.secondTotal:null;

    g.hasFirstRoundData = g.firstExam!==null || g.firstTotal!==null || g.coursework!==null;
    g.hasSecondRoundData = g.secondExam!==null || g.secondTotal!==null;
    g.firstBaseTotal = g.firstTotal!==null ? g.firstTotal : (g.coursework!==null && g.firstExam!==null ? g.coursework+g.firstExam : null);
    g.secondBaseTotal = g.secondTotal!==null ? g.secondTotal : (g.coursework!==null && g.secondExam!==null ? g.coursework+g.secondExam : null);

    // The latest available attempt is authoritative: second round first, otherwise first round.
    g.activeRound = g.hasSecondRoundData ? 2 : (g.hasFirstRoundData ? 1 : 0);
    g.baseTotal = g.activeRound===2 ? g.secondBaseTotal : g.firstBaseTotal;
    g.activeExam = g.activeRound===2 ? g.secondExam : g.firstExam;
    g.effectiveTotal = g.baseTotal===null ? null : g.baseTotal + (g.decision||0);

    const totalPass = g.effectiveTotal!==null && g.effectiveTotal>=50;
    // For ministerial/evaluative subjects (⭐), the active final exam must also be >= 30.
    const examPass = !g.ministerial || (g.activeExam!==null && g.activeExam>=30);
    g.passesCurrentAttempt = totalPass && examPass;
    g.decisionWasNeeded = !!(g.passesCurrentAttempt && g.decision>0 && g.baseTotal!==null && g.baseTotal<50 && g.effectiveTotal>=50);

    if(!g.hasFirstRoundData && !g.hasSecondRoundData) g.status='incomplete';
    else if(g.passesCurrentAttempt) g.status=g.decisionWasNeeded?'pass_decision':'pass';
    else if(g.hasSecondRoundData) g.status='fail';
    else g.status='completer';

    g.statusLabel = statusLabel(g.status);
    return g;
  }

  function statusLabel(status){
    switch(status){
      case 'pass_decision': return 'ناجح بقرار';
      case 'pass': return 'ناجح';
      case 'completer': return 'مكمل';
      case 'fail': return 'راسب';
      default: return 'بيانات ناقصة';
    }
  }

  function computeStudent(s,totalSubjects){
    s.grades=(s.grades||[]).map(prepareGrade);
    s.hasDecision=s.grades.some(g=>g.decision!==null&&g.decision>0);
    s.hasSecondRound=s.grades.some(g=>g.hasSecondRoundData);

    // A student is successful only when ALL subjects are passed.
    // Missing subject data therefore cannot be counted as a pass.
    const statuses=s.grades.map(g=>g.status);
    const missingSubjects=Math.max(0,(totalSubjects||statuses.length)-statuses.length)+statuses.filter(x=>x==='incomplete').length;
    if(!statuses.length || missingSubjects>0) s.status='incomplete';
    else if(statuses.includes('fail')) s.status='fail';
    else if(statuses.includes('completer')) s.status='completer';
    else if(statuses.every(x=>x==='pass'||x==='pass_decision')) s.status=statuses.includes('pass_decision')?'pass_decision':'pass';
    else s.status='incomplete';

    s.computedResult=statusLabel(s.status);
    s.passedByDecision=s.status==='pass_decision';
    s.averageNumber=numeric(s.average);
    s.totalNumber=numeric(s.total);
    return s;
  }

  function buildModel(sheet,sheetName,fileName){
    const detected=detectSubjects(sheet), subjects=detected.subjects, cols=detectSummaryCols(sheet,detected.nextCol);
    const model={
      version:'0.3.0', sourceFile:fileName||'', sheetName:sheetName||'',
      college:stripLabel(sheet.valueAt('A1'),'الكلية'),
      department:stripLabel(sheet.valueAt('A5'),'القسم'),
      studyType:stripLabel(sheet.valueAt('A6'),'نوع الدراسة'),
      stage:stripLabel(sheet.valueAt('A7'),'المرحلة'),
      semester:stripLabel(sheet.valueAt('A8'),'الفصل'),
      academicYear:stripLabel(sheet.valueAt('A9'),'السنة الدراسية'),
      subjects, students:[], summaryColumns:cols, importedAt:new Date().toISOString()
    };
    let row=14, misses=0, guard=0;
    const max=Math.max(sheet.maxRow||0,14);
    while(row<=max+3 && guard++<10000){
      const a=sheet.valueAt(coord(1,row)), b=sheet.valueAt(coord(2,row));
      const mergeA=sheet.findMerge(coord(1,row));
      const rowText=norm(a+' '+b);
      if(rowText.includes('توقيع اللجنة') || (mergeA && mergeA.c1===1 && mergeA.c2>=20)){
        row=(mergeA?mergeA.r2:row)+1; misses=0; continue;
      }
      const serial=integer(a);
      if(serial!==null && b){
        const s={serial,name:String(b).trim(),grades:[]};
        for(const sub of subjects){
          const g=prepareGrade({
            subjectName:sub.displayName||sub.name, ministerial:sub.ministerial,
            decision:numeric(sheet.valueAt(coord(sub.endCol,row))),
            coursework:numeric(sheet.valueAt(coord(sub.startCol,row+1))),
            firstExam:numeric(sheet.valueAt(coord(sub.startCol+1,row+1))),
            firstTotal:numeric(sheet.valueAt(coord(sub.endCol,row+1))),
            secondExam:numeric(sheet.valueAt(coord(sub.startCol+1,row+2))),
            secondTotal:numeric(sheet.valueAt(coord(sub.endCol,row+2)))
          });
          s.grades.push(g);
        }

        // Source result is kept only for audit. It NEVER decides the computed result.
        s.sourceResultFirst=sheet.valueAt(coord(cols.result,row+1));
        s.sourceResultSecond=sheet.valueAt(coord(cols.result,row+2));
        s.result=nonempty(s.sourceResultSecond,s.sourceResultFirst,sheet.valueAt(coord(cols.result,row)));

        // Fields may be updated after second round, therefore prefer the latest non-empty row.
        s.failedSubjects=nonempty(sheet.valueAt(coord(cols.failed,row+2)),sheet.valueAt(coord(cols.failed,row+1)),sheet.valueAt(coord(cols.failed,row)));
        s.carry=nonempty(sheet.valueAt(coord(cols.carry,row+2)),sheet.valueAt(coord(cols.carry,row+1)),sheet.valueAt(coord(cols.carry,row)));
        s.average=nonempty(sheet.valueAt(coord(cols.average,row+2)),sheet.valueAt(coord(cols.average,row+1)),sheet.valueAt(coord(cols.average,row)));
        s.total=nonempty(sheet.valueAt(coord(cols.total,row+2)),sheet.valueAt(coord(cols.total,row+1)),sheet.valueAt(coord(cols.total,row)));
        s.notes=nonempty(sheet.valueAt(coord(cols.notes,row+2)),sheet.valueAt(coord(cols.notes,row+1)),sheet.valueAt(coord(cols.notes,row)));

        computeStudent(s,subjects.length);
        model.students.push(s);
        const span=mergeA && mergeA.c1===1 && mergeA.r1===row ? Math.max(3,mergeA.r2-mergeA.r1+1) : 3;
        row+=span; misses=0; continue;
      }
      if(!a&&!b) misses++; else misses=0;
      if(misses>=12 && row>max) break;
      row++;
    }
    enrich(model);
    return model;
  }

  function enrich(model){
    const st=model.students||[];
    model.stats={
      students:st.length, subjects:(model.subjects||[]).length,
      passed:st.filter(s=>s.status==='pass'||s.status==='pass_decision').length,
      failed:st.filter(s=>s.status==='fail').length,
      completers:st.filter(s=>s.status==='completer').length,
      incomplete:st.filter(s=>s.status==='incomplete').length,
      decisionStudents:st.filter(s=>s.passedByDecision).length,
      secondRoundStudents:st.filter(s=>s.hasSecondRound).length,
      ministerialSubjects:(model.subjects||[]).filter(s=>s.ministerial).length
    };
    model.stats.pending=model.stats.completers+model.stats.incomplete;
    model.stats.passRate=st.length?model.stats.passed*100/st.length:0;
    const avgs=st.map(s=>s.averageNumber).filter(Number.isFinite);
    model.stats.classAverage=avgs.length?avgs.reduce((a,b)=>a+b,0)/avgs.length:0;
    const ranked=st.filter(s=>Number.isFinite(s.averageNumber)).slice().sort((a,b)=>b.averageNumber-a.averageNumber);
    model.rankedStudents=ranked;
    model.stats.topStudent=ranked[0]||null;
    model.stats.lowestStudent=ranked.length?ranked[ranked.length-1]:null;
    model.subjectStats=(model.subjects||[]).map((sub,i)=>{
      let graded=0,passed=0,failed=0,completers=0,incomplete=0,decisions=0,secondRound=0,sum=0;
      for(const s of st){
        const g=s.grades?.[i]; if(!g) { incomplete++; continue; }
        prepareGrade(g);
        const t=g.effectiveTotal;
        if(Number.isFinite(t)){graded++;sum+=t;}
        if(g.status==='pass'||g.status==='pass_decision') passed++;
        if(g.status==='pass_decision') decisions++;
        else if(g.status==='fail') failed++;
        else if(g.status==='completer') completers++;
        else if(g.status==='incomplete') incomplete++;
        if(g.hasSecondRoundData) secondRound++;
      }
      return {subject:sub,graded,passed,failed,completers,incomplete,decisions,secondRound,average:graded?sum/graded:0,passRate:graded?passed*100/graded:0};
    });
    const graded=model.subjectStats.filter(x=>x.graded>0);
    model.stats.strongestSubject=graded.length?graded.slice().sort((a,b)=>b.passRate-a.passRate)[0]:null;
    model.stats.weakestSubject=graded.length?graded.slice().sort((a,b)=>a.passRate-b.passRate)[0]:null;
  }

  function recomputeModel(model){
    if(!model || typeof model!=='object') return model;
    model.version='0.3.0';
    model.subjects=model.subjects||[];
    model.students=model.students||[];
    for(const s of model.students){
      s.grades=s.grades||[];
      s.grades.forEach((g,i)=>{
        if(g.ministerial===undefined && model.subjects[i]) g.ministerial=!!model.subjects[i].ministerial;
        prepareGrade(g);
      });
      if(s.sourceResultFirst===undefined) s.sourceResultFirst=s.result||'';
      if(s.sourceResultSecond===undefined) s.sourceResultSecond='';
      computeStudent(s,model.subjects.length);
    }
    enrich(model);
    return model;
  }

  async function parseArrayBuffer(buffer,fileName=''){
    const JSZipCtor=requireJSZip();
    let zip;
    try{ zip=await JSZipCtor.loadAsync(buffer); }
    catch(e){ throw new Error('الملف المختار ليس ملف Excel صالحًا من نوع XLSX/XLSM أو أنه تالف.'); }
    const shared=await sharedStrings(zip);
    const refs=await workbookSheetPaths(zip);
    if(!refs.length) throw new Error('لم يتم العثور على أوراق عمل داخل ملف Excel.');
    let best=null;
    for(const item0 of refs){
      const item=typeof item0==='string'?{name:'',path:item0}:item0;
      const sheet=await parseSheet(zip,item.path,shared);
      const score=candidateScore(sheet);
      if(!best || score>best.score) best={sheet,name:item.name,score};
    }
    if(!best) throw new Error('تعذر تحديد ورقة الماسترشيت.');
    const model=buildModel(best.sheet,best.name,fileName);
    if(!model.subjects.length || !model.students.length){
      throw new Error(`تم فتح ملف Excel، لكن لم يتم التعرف على قالب الماسترشيت. تم اكتشاف ${model.subjects.length} مادة و${model.students.length} طالب.`);
    }
    return model;
  }

  const api={parseArrayBuffer,recomputeModel,prepareGrade,numeric,norm,coord,parseCoord,version:'0.3.0'};
  global.ASAExcelParser=api;
  if(typeof module!=='undefined'&&module.exports) module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
